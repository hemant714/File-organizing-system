//Array Provieds you and ordered collection of elements

 let arr = []; // array declaration
 

// let cars = ['ferrari' , 2 , true , null] // array initialized
// //in jS array you can store different values of differnet dataTypes

// //console.log('This is cars Array', cars)

// let cars2 = ["Ferrai", "Jaguar", "BMW", "Tesla"];

// //Accesing the elements of an array
// // console.log(cars2[1]); // Jaguar
// // console.log(cars2[0]);
// // console.log(cars2[3]);
// // console.log(cars2[2]);

// //Replace an Element of an Array

// // cars2[2] = "Bentley"; // 2nd index of cars2 wil be replaced with this value
// // console.log(cars2);

// // //Add a new element to an array
// // cars2[4] = "Mercedes";
// // console.log(cars2);

// // cars2[7] = "Maruti";
// // console.log(cars2);

// //Array Methods -

// //pop method () - this method removes the last element from the array

// cars2.pop();
// console.log(cars2);

// // push method - this adds an element at the end of the array
// cars2.push("Rolls Royce");
// console.log(cars2);

// // shift method - removes the elemet from the starting of an array
// cars2.shift();
// console.log(cars2);

// // unshift method - adds an elements to the starting of an array
// cars2.unshift("Ashton Martin");
// console.log(cars2);


//length of an array

//console.log(cars2.length)



//MultiDimensional Arrays 

let matrix = [
       [1 , 2, 3],
       [4 , 5, 6],
       [7 , 8, 9]
]

console.log(matrix[2][1])


// join and split