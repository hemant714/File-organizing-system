const calclulatorModule = require('./calculator') /// here you have imported your module



//Use your Imported Methods like this
calclulatorModule.Multiply(2,3)


calclulatorModule.addition(10,20)

calclulatorModule.substarct(30,10)


calclulatorModule.division(10,5)