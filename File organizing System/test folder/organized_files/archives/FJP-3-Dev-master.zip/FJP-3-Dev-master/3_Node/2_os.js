const os = require('os')

console.log(os.arch()) // architechture (64 or 32)

console.log(os.platform()) // tells about system Platform

console.log(os.networkInterfaces()) // gives details about your Network

console.log(os.cpus()) // cpu specifications